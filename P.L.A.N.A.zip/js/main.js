import { state } from './store.js';
import { initTabs, initShop, initStageFilters, initAcademyFilter, initStudentBonus, initDropTable, updateBonusDashboardIcons, switchTab, toggleStudent, toggleApWidget, toggleAllStages, syncValues, updateTotal, manualTarget, updateCurrent, toggleStudentSelector, toggleBonusFilter, toggleRoleFilter } from './ui.js';
import { calculate, calcAp, updateTotalBonus } from './calc.js';

// [수정됨] 이벤트 목록 로드 및 사이드바 배너 연동
// js/main.js

// ... imports 생략 ...

// [수정됨] 이벤트 목록 로드 및 배지 오버레이 구현
async function loadEventList() {
    try {
        // 경로 확인: 실제 파일 위치에 맞게 설정
        const res = await fetch('src/event/events.json'); 
        if(!res.ok) throw new Error("events.json 로드 실패");
        const events = await res.json();
        
        const listContainer = document.getElementById('eventListContainer');
        listContainer.innerHTML = '';

        events.forEach(ev => {
            const div = document.createElement('div');
            div.className = 'event-item';
            
            // 현재 보고 있는 파일이면 active 표시 및 초기 배너 설정
            if(ev.dataFile === state.currentJsonPath) {
                div.classList.add('active');
                updateMainBanner(ev.bannerImg);
            }
            
            const statusClass = ev.status === '진행중' ? 'ing' : 'end';
            
            // ▼▼▼ [핵심 수정 부분] ▼▼▼
            // 이미지와 배지를 감싸는 wrapper를 만들고, 그 안에 이미지와 배지를 넣습니다.
            div.innerHTML = `
                <div class="banner-wrapper">
                    <img src="${ev.bannerImg}" class="list-banner-img" alt="${ev.name}">
                    <span class="status-badge-overlay ${statusClass}">${ev.status}</span>
                </div>
            `;
            // ▲▲▲ 수정 끝 ▲▲▲
            
            div.onclick = () => {
                loadDataAndInit(ev.dataFile);
                updateMainBanner(ev.bannerImg);
                document.querySelectorAll('.event-item').forEach(el => el.classList.remove('active'));
                div.classList.add('active');
                // toggleEventListUI(); // 모바일에서 클릭 후 닫고 싶으면 주석 해제
            };
            listContainer.appendChild(div);
        });
    } catch (e) { console.log("이벤트 목록 로드 에러:", e); }
}

// ... 나머지 함수들 그대로 유지 ...

// [신규] 좌측 메인 배너 이미지 변경 함수
function updateMainBanner(imgSrc) {
    const bannerImg = document.querySelector('.banner-area img');
    if (bannerImg) {
        bannerImg.src = imgSrc;
        bannerImg.style.display = 'block'; // 에러로 숨겨졌을 경우 다시 표시
    }
}

function toggleEventListUI() {
    const el = document.getElementById('eventListContainer');
    el.classList.toggle('hidden');
}

async function loadDataAndInit(jsonPath) {
    try {
        const response = await fetch(jsonPath);
        if (!response.ok) throw new Error(`${jsonPath} load failed`);
        const data = await response.json();

        resetState();
        state.currentJsonPath = jsonPath;

        if (data.eventSettings) {
            state.currencyIcons = data.eventSettings.currencyIcons || [];
            state.tabMap = data.eventSettings.tabMap || [0, 1, 3];
            state.tabDisplayMap = data.eventSettings.tabDisplayMap || state.tabMap;
            state.shopTabIcons = data.eventSettings.shopTabIcons || [1, 2, 3];
            state.bonusDashboardIcons = data.eventSettings.bonusDashboardIcons || [0, 1, 2];
        }

        state.itemMap = data.itemMap || {};
        state.shopConfig = data.shopConfig;
        state.stageConfig = data.stageConfig;

        try {
            const charRes = await fetch('characters.json'); 
            if (charRes.ok) {
                const rawChars = await charRes.json();
                const bonusMap = data.studentBonuses || {};
                
                state.studentData = rawChars
                    .filter(char => bonusMap.hasOwnProperty(char.name))
                    .map(char => {
                        return { ...char, bonus: bonusMap[char.name] };
                    });
            }
        } catch (e) { console.error(e); }

        initTabs();      
        initShop();      
        initStageFilters(); 
        initAcademyFilter();
        initStudentBonus(); 
        initDropTable(); 
        updateBonusDashboardIcons();
        calculate();     

        const tAmt = document.getElementById('targetAmount');
        const cAmt = document.getElementById('currentAmount');
        const bRate = document.getElementById('bonusRate');
        if(tAmt) tAmt.value = 0;
        if(cAmt) cAmt.value = 0;
        if(bRate) bRate.value = 0;

    } catch (error) {
        console.error(error);
        alert(`데이터 로드 실패: ${jsonPath}\n(경로를 확인해주세요)`);
    }
}

function resetState() {
    state.currentTab = 0;
    state.tabTotals = [0, 0, 0];
    state.globalCurrentAmounts = [0, 0, 0];
    state.selectedStudents.clear();
    state.activeBonusFilter = -1;
    state.currentAcademy = "ALL";
}

window.switchTab = switchTab;
window.toggleApWidget = toggleApWidget;
window.adjustAp = (d) => { const i = document.getElementById('curAp'); let v = (parseInt(i.value)||0)+d; if(v<0)v=0; if(v>240)v=240; i.value=v; calcAp(); };
window.calcAp = calcAp;
window.toggleStudentSelector = toggleStudentSelector;
window.toggleBonusFilter = toggleBonusFilter;
window.toggleRoleFilter = toggleRoleFilter;
window.toggleStudent = toggleStudent;
window.manualTarget = manualTarget;
window.updateCurrent = updateCurrent;
window.calculate = calculate;
window.syncValues = syncValues;
window.updateTotal = updateTotal;
window.toggleAllStages = toggleAllStages;
window.filterByAcademy = (ac) => { state.currentAcademy = ac; initStudentBonus(); };
window.toggleEventListUI = toggleEventListUI;

window.addEventListener('DOMContentLoaded', () => {
    // 초기 로딩: 경로를 'src/event/data/...' 로 정확히 맞춰주세요
    loadDataAndInit('src/event/data/ev_852.json'); 
    loadEventList();
});