// constants.js
export const IMG_PATH = "src/";
export const DEFAULT_IMG = "marieyon.png";
export const AP_ICON_PATH = "src/ui/Currency_Icon_AP.png";